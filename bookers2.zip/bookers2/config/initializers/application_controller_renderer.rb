# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'fe58e17627aab2b07894b138aecfb3ca0700ff890a8ef51f3a6a2bf27645005846bc28d3caca2f8a0faa29c03fa6f8805b54de769d97f436398bf2ef70735669'
